
module.exports = {
  darkMode: 'class',
  content: [
    './pages/**/*.{js,ts,jsx,tsx}',
    './components/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        ultrabold: ['Space Grotesk', 'sans-serif'],
      },
      colors: {
        purple: {
          500: '#8833ff',
        },
      },
    },
  },
  plugins: [],
};
    